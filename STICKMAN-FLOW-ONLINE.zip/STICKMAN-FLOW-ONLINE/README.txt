STICKMAN FLOW ONLINE

1) Extract this ZIP.
2) Upload the STICKMAN-FLOW-ONLINE folder to a static hosting service such as Netlify Drop.
3) The main page is index.html.
4) Share the generated https:// link, not a file:/// link.
